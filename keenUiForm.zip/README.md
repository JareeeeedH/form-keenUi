# vue-keen

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).


- 輸入時驗證，送出時全部驗證，顯示錯誤在欄位下方
- 帳號/必填 4-20 英文小寫,數字
- 密碼/必填 6-12 英文小寫,數字
- 密碼確認
- name:必填，不可數字 空白 特殊符號
- gender; 非必填,下拉選單
- email/ 非必填, 符合格式
- 送出後，下方顯示資料格式